$(document).ready(function() {
	//$('input[required]').addClass('highlighted');
	//$('input[placeholder=Email]').addClass('highlighted');
	$('input[placeholder*=Name]').addClass('highlighted');
});