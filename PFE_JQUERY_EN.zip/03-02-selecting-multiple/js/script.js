$(document).ready(function() {
	$('.class1, .class2').addClass('highlighted');
});