$(document).ready(function() {
	//our code goes
	//$('#container').text('hello');
	$('.class1').text('hello');
});