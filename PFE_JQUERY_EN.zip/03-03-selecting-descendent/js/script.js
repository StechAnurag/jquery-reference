$(document).ready(function() {
	//$('#listing li').addClass('highlighted');
	$('#listing > li').addClass('highlighted');
});